public interface Product {
    Product copy(); // Method to create a copy
    void displayDetails(); // Method to display product details
}
