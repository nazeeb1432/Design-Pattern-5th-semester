class LedgerService {
    public void makeEntry(String cardNumber, double amount) {
        // Make a ledger entry for the transaction
        System.out.println("LedgerService: Making ledger entry for card " + cardNumber + " with amount " + amount);
    }
}
