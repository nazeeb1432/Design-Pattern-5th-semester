class AccountService {
    public boolean checkAccount(String cardNumber) {
        // Check if the account exists based on card number
        System.out.println("AccountService: Checking account for card " + cardNumber);
        return true; // Assuming account exists for simplicity
    }
}
