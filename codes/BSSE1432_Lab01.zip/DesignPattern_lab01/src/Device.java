public interface Device {
    public void powerON();
    public  void powerOff();
}
