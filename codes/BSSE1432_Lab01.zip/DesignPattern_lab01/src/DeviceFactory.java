public abstract class DeviceFactory {
    public abstract Device createDevice(Object... attributes);
}
