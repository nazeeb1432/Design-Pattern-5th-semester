import java.util.UUID;

public interface Sofa {
    void lieOn();
    String getMaterial();
    String getColor();
    void recline();
    UUID getUUID();
}
