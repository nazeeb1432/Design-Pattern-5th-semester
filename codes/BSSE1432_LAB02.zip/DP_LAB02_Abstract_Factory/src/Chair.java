import java.util.UUID;

public interface Chair {
    void sitOn();
    String getMaterial();
    String getColor();
    UUID getUUID();
}
