import java.util.UUID;

public interface Table {
    void placeItems();
    String getMaterial();
    String getColor();
    UUID getUUID()
}
